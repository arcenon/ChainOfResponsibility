package model;

import model.dishes.*;

/**
 * @author Jacinthe van Niele en Robert Kensen on 7-3-2021
 * @project ChainOfResponsibility
 * This class represents a Base Handler in a 'Chain of Responsibility' design pattern.
 * SushiMenuComposer defines the default handling behaviour. It can be altered though!
 */

public class Order {
    protected static SushiMenuComposer goldenDish = new GoldenDish();
    protected static SushiMenuComposer redDish = new RedDish();
    protected static SushiMenuComposer greenDish = new GreenDish();
    protected static  SushiMenuComposer blueDish = new BlueDish();
    protected static SushiMenuComposer yellowDish = new YellowDish();

    // Een oplossing voor het willekeurig aanspreken van de handlers kan een switch statement zijn
    protected static SushiMenuComposer composerChain;

    static {
        blueDish.setNextSushiComposer(yellowDish); // Added this loop to connect the head to the tail
        yellowDish.setNextSushiComposer(goldenDish);
        goldenDish.setNextSushiComposer((redDish));
        redDish.setNextSushiComposer(greenDish);
        greenDish.setNextSushiComposer(blueDish);
        composerChain = goldenDish;
    }

    public static void order(Credits credits){
        if (credits != null){
            composerChain.compose(credits);
        }
    }
}
